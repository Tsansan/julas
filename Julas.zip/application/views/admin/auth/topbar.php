<!-- main page -->
<div class="col-10 c-last">


    <!-- top bar -->
    <div class="col border-bottom" style="height: 3rem;">
        <h1 class="fs-4 pt-2">SMP Negeri 2 Sidoharjo</h1>
    </div>
    <!-- end topbar -->